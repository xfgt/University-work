package org.example.mid;

public interface Payable {
    double calculatePay();
}
