package org.example.easy;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringUtilsTest {

    @Test
    void reverse() {
    }

    @Test
    void isPalindrome() {
    }

    @Test
    void countVowels() {
    }

    @Test
    void toTitleCase() {
    }

    @Test
    void removeSpaces() {
    }
}