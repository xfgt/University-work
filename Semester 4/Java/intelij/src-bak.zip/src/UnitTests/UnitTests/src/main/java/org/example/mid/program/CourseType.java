package org.example.mid.program;

public enum CourseType {
    REQUIRED, ELECTIVE

}
